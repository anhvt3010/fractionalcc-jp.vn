<?php defined( 'ABSPATH' ) || exit; ?>
<div class="hero-viewport-wrap">
      
      <section class="hero-section">
        <div class="container hero-grid">
          <div class="hero-content">
            <div class="hero-badge-wrap">
              <span class="badge-pill badge-gold"><?php echo project_child_fcc_text( 'fcc_ui_fbc8886b40af10', 'home' ); ?></span>
              <span class="badge-pill badge-dark"><?php echo project_child_fcc_text( 'fcc_ui_1b556d0408712c', 'home' ); ?></span>
            </div>
            
            <h1 class="hero-title heading-serif">
              <?php echo project_child_fcc_text( 'fcc_ui_487435027051ea', 'home' ); ?> <span style="color: var(--color-accent-gold);"><?php echo project_child_fcc_text( 'fcc_ui_7c4ad8cffee502', 'home' ); ?></span>
            </h1>
            
            <p class="hero-subtitle">
              <?php echo project_child_fcc_text( 'fcc_ui_543aa81dfd94d5', 'home' ); ?> <strong><?php echo project_child_fcc_text( 'fcc_ui_88efa52705849b', 'home' ); ?></strong><?php echo project_child_fcc_text( 'fcc_ui_ea89cea6464acf', 'home' ); ?>
            </p>

            <div class="hero-cta-group">
              <button class="btn btn-primary" data-open-order data-product-select="<?php echo esc_attr( project_child_fcc_order_code( 'combo_C-CX4' ) ); ?>">
                <?php echo project_child_fcc_text( 'fcc_ui_e05dc8077446a2', 'home', false ); ?>
              </button>
              <a href="#san-pham-chu-luc" class="btn btn-outline">
                <?php echo project_child_fcc_text( 'fcc_ui_378ce494d40351', 'home', false ); ?>
              </a>
            </div>

            <div class="hero-trust-micro">
              <div class="hero-stars">★★★★★</div>
              <span><?php echo project_child_fcc_text( 'fcc_ui_898c9707cbc6fb', 'home' ); ?></span>
            </div>
          </div>

          <div class="hero-visual">
            <div class="hero-card">
              <img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_453bd451ef0751' ) ); ?>" alt="<?php echo esc_attr( project_child_fcc_image_alt( 'fcc_ui_453bd451ef0751', 'fcc_ui_eeddc60a6e4bec' ) ); ?>" class="hero-banner-img" loading="eager">
            </div>
          </div>
        </div>
      </section>

      
      <section class="trust-bar">
        <div class="container">
          <div class="trust-bar-grid">
            
            <div class="trust-bar-item">
              <div class="trust-bar-icon-wrap" title="<?php echo esc_attr( project_child_fcc_raw_text( 'fcc_ui_722cc950bbd51f', 'shared' ) ); ?>">
                <svg width="28" height="20" viewbox="0 0 24 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="border-radius: 2px; box-shadow: 0 0 2px rgba(0,0,0,0.25);">
                  <rect width="24" height="16" fill="#FFFFFF"></rect>
                  <circle cx="12" cy="8" r="4.8" fill="#BC002D"></circle>
                </svg>
              </div>
              <div class="trust-bar-content">
                <h4><?php echo project_child_fcc_text( 'fcc_ui_c92fd3458a307a', 'home' ); ?></h4>
                <p><?php echo project_child_fcc_text( 'fcc_ui_18645916ec2e37', 'home' ); ?></p>
              </div>
            </div>

            
            <div class="trust-bar-item">
              <div class="trust-bar-icon-wrap" title="<?php echo esc_attr( project_child_fcc_raw_text( 'fcc_ui_0db343ac35a4d7', 'shared' ) ); ?>">
                <img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="<?php echo esc_attr( project_child_fcc_image_alt( 'fcc_ui_be08f7c57f78ec', 'fcc_ui_6d82420f357692' ) ); ?>" style="width: 40px; height: 40px; object-fit: contain; border-radius: 50%;">
              </div>
              <div class="trust-bar-content">
                <h4><?php echo project_child_fcc_text( 'fcc_ui_7f36fd34e50688', 'home' ); ?></h4>
                <p><?php echo project_child_fcc_text( 'fcc_ui_3cb5377b9686ad', 'home' ); ?></p>
              </div>
            </div>

            
            <div class="trust-bar-item">
              <div class="trust-bar-icon-wrap" title="<?php echo esc_attr( project_child_fcc_raw_text( 'fcc_ui_2e477cc3b39cf0', 'shared' ) ); ?>">
                <svg width="22" height="22" viewbox="0 0 24 24" fill="none" stroke="#C5A059" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                  <path d="m9 12 2 2 4-4"></path>
                </svg>
              </div>
              <div class="trust-bar-content">
                <h4><?php echo project_child_fcc_text( 'fcc_ui_7fae43eabd17c5', 'home' ); ?></h4>
                <p><?php echo project_child_fcc_text( 'fcc_ui_740d386bb06816', 'home' ); ?></p>
              </div>
            </div>

            
            <div class="trust-bar-item">
              <div class="trust-bar-icon-wrap" title="<?php echo esc_attr( project_child_fcc_raw_text( 'fcc_ui_8ce2cfbee099eb', 'shared' ) ); ?>">
                <svg width="22" height="22" viewbox="0 0 24 24" fill="none" stroke="#C5A059" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14"></path>
                  <path d="m7.5 4.27 9 5.15"></path>
                  <polyline points="3.29 7 12 12 20.71 7"></polyline>
                  <line x1="12" y1="22" x2="12" y2="12"></line>
                  <circle cx="18.5" cy="18.5" r="2.5"></circle>
                  <path d="m17.5 18.5 1 1 2-2"></path>
                </svg>
              </div>
              <div class="trust-bar-content">
                <h4><?php echo project_child_fcc_text( 'fcc_ui_71d9bd21e43bed', 'home' ); ?></h4>
                <p><?php echo project_child_fcc_text( 'fcc_ui_ad6fe4262d4b15', 'home' ); ?></p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
