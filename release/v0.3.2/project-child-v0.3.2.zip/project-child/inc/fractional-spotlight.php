<?php
/** Editable spotlight presentation for selected products and combos. @package Project_Child */
defined( 'ABSPATH' ) || exit;

function project_child_fcc_spotlight_fields() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) { return; }
	$fields = array();
	foreach ( array( 'spotlightTitle' => 'Tiêu đề trên thẻ', 'spotlightDescription' => 'Mô tả trên thẻ', 'spotlightRating' => 'Dòng đánh giá / thông tin bổ sung', 'spotlightSpecs' => 'Thông số trong nhãn', 'spotlightHighlights' => 'Các điểm nổi bật', 'spotlightGift' => 'Thông tin quà tặng', 'spotlightDetailLabel' => 'Chữ nút xem chi tiết', 'spotlightBuyLabel' => 'Chữ nút mua' ) as $name => $label ) {
		$fields[] = array( 'key' => 'field_fcc_' . $name, 'name' => 'fcc_' . $name, 'label' => $label, 'type' => in_array( $name, array( 'spotlightDescription', 'spotlightHighlights' ), true ) ? 'textarea' : 'text', 'rows' => 4, 'instructions' => 'spotlightHighlights' === $name ? 'Mỗi ý một dòng: Nhãn | Mô tả. Chỉ dùng nội dung đã được duyệt.' : 'Để trống để dùng thông tin hồ sơ nếu có. Đánh giá và quà tặng chỉ nhập khi có nguồn xác nhận.' );
	}
	acf_add_local_field_group( array( 'key' => 'group_fcc_spotlight', 'title' => 'Thông tin thẻ sản phẩm chủ lực', 'fields' => $fields, 'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'fcc_product' ) ), array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'fcc_combo' ) ) ) ) );
}
add_action( 'acf/init', 'project_child_fcc_spotlight_fields' );

function project_child_fcc_spotlight_data( $post, $combos ) {
	$is_combo = 'fcc_combo' === $post->post_type;
	$data = $is_combo ? ( isset( $combos[ $post->ID ] ) ? $combos[ $post->ID ] : array() ) : project_core_fcc_product( $post->ID, true );
	if ( ! $data ) { return array(); }
	$data['url'] = $is_combo ? project_core_fcc_url( 'catalog' ) : $data['url'];
	$data['order_code'] = ( $is_combo ? 'combo_' : 'prod_' ) . $post->ID;
	$image_id = absint( get_post_meta( $post->ID, 'fcc_image', true ) );
	$data['alt'] = get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ?: $data['name'];
	$fallbacks = array(
		'spotlightTitle' => $data['name'],
		'spotlightDescription' => $is_combo ? $data['idealFor'] : $data['tagline'],
		'spotlightRating' => ! $is_combo && null !== $data['rating'] ? $data['rating'] . ( null !== $data['reviewCount'] ? ' (' . $data['reviewCount'] . ' đánh giá)' : '' ) : '',
		'spotlightSpecs' => $is_combo ? implode( ' • ', $data['productsIncluded'] ) : implode( ' • ', array_filter( array( $data['cbmp'] ? 'Số CBMP: ' . $data['cbmp'] : '', $data['volume'] ? 'Dung tích: ' . $data['volume'] : '' ) ) ),
		'spotlightHighlights' => $is_combo ? '' : implode( "\n", array_map( function ( $active ) { return $active['name'] . ' | ' . $active['desc']; }, $data['actives'] ) ),
		'spotlightGift' => $is_combo ? $data['gift'] : '',
		'spotlightDetailLabel' => $is_combo ? 'Xem combo' : 'Xem Chi Tiết',
		'spotlightBuyLabel' => $is_combo ? 'MUA COMBO NGAY' : 'MUA NGAY',
	);
	foreach ( $fallbacks as $name => $fallback ) {
		$value = get_post_meta( $post->ID, 'fcc_' . $name, true );
		$data[ $name ] = is_string( $value ) && '' !== $value ? $value : $fallback;
	}
	return $data;
}

/** Plain text with optional label separators; all stored content remains escaped. */
function project_child_fcc_spotlight_line( $text ) {
	$parts = explode( '|', $text );
	foreach ( $parts as $index => $part ) {
		if ( count( $parts ) > 1 && 0 === $index % 2 ) { echo '<strong>' . esc_html( trim( $part ) ) . '</strong> '; }
		else { echo esc_html( trim( $part ) ) . ' '; }
	}
}
