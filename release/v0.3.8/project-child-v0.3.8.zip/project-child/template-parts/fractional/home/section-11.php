<?php defined( 'ABSPATH' ) || exit; ?>
<section class="final-cta-section">
      <div class="final-cta-banner">
        
        <div class="final-cta-watermark" aria-hidden="true">
          <div class="wm-monogram-grid">
            
            <div class="wm-grid-row wm-row-odd">
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
            </div>

            
            <div class="wm-grid-row wm-row-even">
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
            </div>

            
            <div class="wm-grid-row wm-row-odd">
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
            </div>

            
            <div class="wm-grid-row wm-row-even">
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_be08f7c57f78ec' ) ); ?>" alt="" class="wm-cell-logo-bd"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_d7e807fe2d526b', 'home' ); ?></span></div>
              <span class="wm-cell-star"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
              <div class="wm-cell"><img src="<?php echo esc_url( project_child_fcc_image( 'fcc_ui_73ad1fb64a971c' ) ); ?>" alt="" class="wm-cell-logo-cc"><span class="wm-cell-name"><?php echo project_child_fcc_text( 'fcc_ui_c772c04d8802f5', 'home' ); ?></span></div>
            </div>
          </div>
        </div>

        
        <div class="container final-cta-content">
          <div class="final-cta-badge">
            <span class="final-cta-badge-dot"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
            <span><?php echo project_child_fcc_text( 'fcc_ui_cb085d11a08144', 'home' ); ?></span>
            <span class="final-cta-badge-dot"><?php echo project_child_fcc_text( 'fcc_ui_a1a6df710dbb23', 'home' ); ?></span>
          </div>

          <h2 class="final-cta-title heading-serif">
            <?php echo project_child_fcc_text( 'fcc_ui_2c8d427ab152ee', 'home' ); ?> <span class="final-cta-title-gold"><?php echo project_child_fcc_text( 'fcc_ui_678d18c5839fc1', 'home' ); ?></span>
          </h2>

          <p class="final-cta-sub">
            <?php echo project_child_fcc_text( 'fcc_ui_04e30839b767fe', 'home' ); ?>
          </p>

          <div class="final-cta-actions">
            <button class="btn-final-cta-buy" data-open-order data-product-select="<?php echo esc_attr( project_child_fcc_order_code( 'combo_C-CX4' ) ); ?>">
              <span><?php echo project_child_fcc_text( 'fcc_ui_afd0f22490cecf', 'home', false ); ?></span>
              <svg width="18" height="18" viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </button>
          </div>

          <div class="final-cta-contacts-row">
            <a href="<?php echo esc_url( project_child_fcc_link( 'https://zalo.me/0985561862' ) ); ?>" target="_blank" rel="noopener noreferrer" class="contact-pill-btn contact-pill-zalo">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C6.477 2 2 6.03 2 11C2 13.565 3.195 15.864 5.12 17.472L4.2 21.2C4.085 21.664 4.545 22.052 4.965 21.848L9.29 19.742C10.158 19.911 11.063 20 12 20C17.523 20 22 15.97 22 11C22 6.03 17.523 2 12 2Z" fill="#FFFFFF"></path><text x="12" y="14" font-family="'Plus Jakarta Sans', Arial, sans-serif" font-size="7.2" font-weight="800" fill="#0068FF" text-anchor="middle" letter-spacing="-0.3">Zalo</text></svg>
              <span>Chat Zalo</span>
            </a>

            <a href="<?php echo esc_url( project_child_fcc_link( 'https://m.me/buidangjp' ) ); ?>" target="_blank" rel="noopener noreferrer" class="contact-pill-btn contact-pill-messenger">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.36 2 2 6.13 2 11.7c0 2.91 1.19 5.44 3.12 7.15.16.14.26.35.26.57l-.37 2.21c-.08.47.38.86.82.7l2.58-1.02c.18-.07.38-.07.56-.01.95.26 1.97.4 3.03.4 5.64 0 10-4.13 10-9.7S17.64 2 12 2zm1 10.5-2.5-2.5-3.5 3.5 3-4.5 2.5 2.5 3.5-3.5-3 4.5z"/></svg>
              <span>Messenger</span>
            </a>

            <a href="<?php echo esc_url( project_child_fcc_link( 'tel:0985561862' ) ); ?>" class="contact-pill-btn contact-pill-phone">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
              <span>Hotline 0985 561 862</span>
            </a>
          </div>

          <div class="final-cta-direct-info">
            <span>Hotline: <a href="<?php echo esc_url( project_child_fcc_link( 'tel:0985561862' ) ); ?>"><?php echo esc_html( project_core_fcc_site( 'hotlineDisplay', '0985 561 862' ) ); ?></a></span>
            <span class="final-cta-info-sep">•</span>
            <span>Email: <a href="<?php echo esc_url( project_child_fcc_link( 'mailto:jpbuidangco.ltd@gmail.com' ) ); ?>"><?php echo esc_html( project_core_fcc_site( 'email', 'jpbuidangco.ltd@gmail.com' ) ); ?></a></span>
          </div>

          <div class="final-cta-trust-bar">
            <span class="final-cta-trust-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DFBA73" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
              <strong>Giao hàng:</strong> Toàn quốc 2–5 ngày
            </span>
            <span class="final-cta-trust-sep">•</span>
            <span class="final-cta-trust-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DFBA73" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
              <strong>Phí vận chuyển:</strong> Báo khi xác nhận đơn
            </span>
            <span class="final-cta-trust-sep">•</span>
            <span class="final-cta-trust-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DFBA73" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="5" rx="2"></rect><line x1="2" x2="22" y1="10" y2="10"></line></svg>
              <strong>Thanh toán:</strong> COD / Chuyển khoản
            </span>
            <span class="final-cta-trust-sep">•</span>
            <span class="final-cta-trust-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DFBA73" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
              <strong>Kiểm tra hàng:</strong> Vui lòng kiểm tra khi nhận
            </span>
          </div>
        </div>
      </div>
    </section>
