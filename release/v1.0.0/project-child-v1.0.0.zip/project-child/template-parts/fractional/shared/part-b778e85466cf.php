<?php defined( 'ABSPATH' ) || exit; ?>
<div class="mobile-sticky-bar">
    <a <?php project_child_fcc_contact_attributes( 'hotline' ); ?> class="btn-mobile-call">
      <span><?php echo project_child_fcc_text( 'fcc_ui_020367c06caf00', 'shared', false ); ?></span>
      <span><?php echo project_child_fcc_text( 'fcc_ui_07358083768019', 'shared', false ); ?></span>
    </a>
    <button class="btn-mobile-buy" data-open-order id="pd-mobile-buy-btn">
      <span><?php echo project_child_fcc_text( 'fcc_ui_9681bed187e219', 'shared', false ); ?></span>
    </button>
  </div>
