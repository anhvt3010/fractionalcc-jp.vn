<?php
/**
 * Main Skin Concerns & Scientific Solutions section template.
 *
 * @package Project_Child
 */
defined( 'ABSPATH' ) || exit;

// Fetch products & combos from project-core
$product_mandelic = function_exists( 'project_core_fcc_product' ) ? project_core_fcc_product( 28, true ) : array();
$product_needle_a = function_exists( 'project_core_fcc_product' ) ? project_core_fcc_product( 40, true ) : array();
$product_needle_ax4 = function_exists( 'project_core_fcc_product' ) ? project_core_fcc_product( 47, true ) : array();
$product_needle_c = function_exists( 'project_core_fcc_product' ) ? project_core_fcc_product( 60, true ) : array();
$product_needle_cx4 = function_exists( 'project_core_fcc_product' ) ? project_core_fcc_product( 65, true ) : array();
$product_pdrn = function_exists( 'project_core_fcc_product' ) ? project_core_fcc_product( 72, true ) : array();

$combos = function_exists( 'project_core_fcc_combos' ) ? project_core_fcc_combos() : array();
$combo_c_cx4 = ! empty( $combos[0] ) ? $combos[0] : null;

$hotline_display = function_exists( 'project_core_fcc_site' ) ? project_core_fcc_site( 'hotlineDisplay', '0985 561 862' ) : '0985 561 862';
$hotline = function_exists( 'project_core_fcc_site' ) ? project_core_fcc_site( 'hotline', '0985561862' ) : '0985561862';
$email = function_exists( 'project_core_fcc_site' ) ? project_core_fcc_site( 'email', 'jpbuidangco.ltd@gmail.com' ) : 'jpbuidangco.ltd@gmail.com';
?>

<!-- BREADCRUMB & HERO HEADER -->
<section class="concerns-hero-header">
  <div class="container">
    <nav class="breadcrumb-nav" aria-label="Breadcrumb">
      <a href="<?php echo esc_url( project_child_fcc_link( 'index.html' ) ); ?>">Trang chủ</a>
      <span aria-hidden="true">/</span>
      <strong>Vấn đề làn da &amp; Giải pháp</strong>
    </nav>

    <div class="concerns-hero-content">
      <div class="concerns-hero-badge">
        <span class="badge-dot">✦</span>
        <span>KHOA HỌC LÀN DA • CHUẨN SALON TOKYO</span>
        <span class="badge-dot">✦</span>
      </div>

      <h1 class="heading-serif concerns-hero-title">
        LÀN DA CỦA BẠN ĐANG GẶP NHỮNG VẤN ĐỀ GÌ?
      </h1>

      <p class="concerns-hero-sub">
        Bạn đã chăm sóc da mỗi ngày nhưng làn da vẫn chưa đạt được vẻ rạng rỡ như mong muốn?
      </p>

      <div class="concerns-intro-box">
        <div class="concerns-intro-icon" aria-hidden="true">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="16" x2="12" y2="12"></line>
            <line x1="12" y1="8" x2="12.01" y2="8"></line>
          </svg>
        </div>
        <div class="concerns-intro-text">
          <p>
            <strong>Hiểu đúng về rào cản làn da:</strong> Lớp sừng biểu bì tự nhiên vốn là hàng rào bảo vệ vững chắc. Khi da chịu tác động từ khói bụi, dày sừng hay suy giảm chuyển hóa theo tuổi tác, các loại tinh chất thông thường rất khó đi sâu, phần lớn chỉ lưu lại trên bề mặt và nhanh chóng bốc hơi.
          </p>
          <p style="margin-bottom: 0;">
            <strong>Giải pháp từ Fractional CC:</strong> Ứng dụng công nghệ vi kim mỹ phẩm sinh học từ bọt biển thủy phân (Hydrolyzed Sponge) tạo hàng ngàn đường dẫn siêu vi dẫn truyền hoạt chất sâu vào biểu bì, kết hợp nồng độ hoạt chất chuẩn xác (Vitamin C, Retinol, Mandelic Acid, PDRN) nhằm hỗ trợ cải thiện bề mặt và tái sinh làn da khỏe khoắn tự nhiên.
          </p>
        </div>
      </div>

      <!-- Quick navigator pills -->
      <div class="concerns-quick-nav">
        <span class="concerns-quick-label">Chọn tình trạng da của bạn:</span>
        <div class="concerns-quick-pills">
          <a href="#dom-nau" class="concern-quick-pill">
            <span class="pill-num">01</span> Đốm Nâu &amp; Không Đều Màu
          </a>
          <a href="#lo-chan-long" class="concern-quick-pill">
            <span class="pill-num">02</span> Lỗ Chân Lông To &amp; Da Sần
          </a>
          <a href="#lao-hoa" class="concern-quick-pill">
            <span class="pill-num">03</span> Lão Hóa &amp; Nếp Nhăn
          </a>
          <a href="#tham-mun" class="concern-quick-pill">
            <span class="pill-num">04</span> Da Thâm Mụn Sau Viêm
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- MAIN CONTENT WRAPPER -->
<div class="concerns-body-wrap">
  <div class="container">

    <!-- 01. ĐỐM NÂU, DA KHÔNG ĐỀU MÀU -->
    <section class="concern-card-block" id="dom-nau">
      <div class="concern-header-row">
        <div class="concern-badge-col">
          <span class="concern-index">01</span>
          <span class="concern-tag">SẮC TỐ &amp; ĐỘ RẠNG RỠ</span>
        </div>
        <h2 class="heading-serif concern-block-title">ĐỐM NÂU, DA KHÔNG ĐỀU MÀU</h2>
      </div>

      <div class="concern-analysis-grid">
        <div class="concern-pain-panel">
          <div class="panel-label panel-label-pain">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
            <span>Nỗi lòng thường gặp</span>
          </div>
          <blockquote class="concern-quote">
            “Những vùng da sậm màu khiến tổng thể gương mặt thiếu tươi tắn, bạn ngại để mặt mộc và phải phụ thuộc nhiều hơn vào lớp trang điểm.”
          </blockquote>
          <div class="concern-insight">
            <h4 class="insight-title">Nguyên nhân từ góc nhìn khoa học:</h4>
            <p>
              Tia UV và các gốc tự do kích hoạt tế bào hắc tố melanocyte sản sinh melanin phân tán không đều. Các serum Vitamin C thông thường dạng bôi thoa ngoài rất dễ bị oxy hóa trên bề mặt trước khi kịp tiếp cận tầng sinh sắc tố, khiến việc cải thiện màu da diễn ra chậm chạp.
            </p>
          </div>
        </div>

        <div class="concern-solution-panel">
          <div class="panel-label panel-label-solution">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <span>Giải pháp từ Fractional CC</span>
          </div>
          <p class="solution-summary">
            Hệ vi kim Hydrolyzed Sponge đóng vai trò như hệ dẫn truyền vi mô, đưa trực tiếp các dẫn xuất Vitamin C nồng độ cao vào lớp biểu bì, phân tán nhẹ nhàng các mảng sẫm màu và hỗ trợ làm sáng đều tông da mà không gây lột tẩy bào mòn.
          </p>
          <ul class="solution-points">
            <li><strong>Needle Serum C (Dưỡng sáng):</strong> Dành cho bước làm quen, nuôi dưỡng làn da tươi tắn và tăng sức đề kháng biểu bì.</li>
            <li><strong>Needle Serum CX4 (Dưỡng sáng X4):</strong> Tăng cường mật độ vi kim và phức hợp Vitamin C chuyên sâu cho vùng đốm nâu lâu năm.</li>
          </ul>
        </div>
      </div>

      <!-- Suggested Products Row -->
      <div class="concern-products-section">
        <h3 class="concern-products-heading">Sản phẩm chủ lực gợi ý:</h3>
        <div class="concern-products-grid">
          <?php
          if ( ! empty( $product_needle_cx4 ) ) {
            get_template_part( 'template-parts/fractional/components/product-card', null, array( 'product' => $product_needle_cx4 ) );
          }
          if ( ! empty( $product_needle_c ) ) {
            get_template_part( 'template-parts/fractional/components/product-card', null, array( 'product' => $product_needle_c ) );
          }
          ?>
        </div>
      </div>
    </section>

    <!-- 02. LỖ CHÂN LÔNG TO -->
    <section class="concern-card-block" id="lo-chan-long">
      <div class="concern-header-row">
        <div class="concern-badge-col">
          <span class="concern-index">02</span>
          <span class="concern-tag">BỀ MẶT &amp; ĐỘ MỊN MÀNG</span>
        </div>
        <h2 class="heading-serif concern-block-title">LỖ CHÂN LÔNG TO &amp; BỀ MẶT KÉM MỊN</h2>
      </div>

      <div class="concern-analysis-grid">
        <div class="concern-pain-panel">
          <div class="panel-label panel-label-pain">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
            <span>Nỗi lòng thường gặp</span>
          </div>
          <blockquote class="concern-quote">
            “Lỗ chân lông to khiến bề mặt da kém mịn, lớp nền dễ lộ khuyết điểm, khiến làn da trông kém rạng rỡ dù bạn vẫn chăm sóc da đều đặn.”
          </blockquote>
          <div class="concern-insight">
            <h4 class="insight-title">Nguyên nhân từ góc nhìn khoa học:</h4>
            <p>
              Bã nhờn tích tụ kết hợp tế bào chết ứ đọng tạo thành các nút sừng làm cổ nang lông giãn rộng cơ học. Khi bề mặt sần sùi, ánh sáng bị tán xạ hỗn loạn khiến làn da trông xỉn màu và lớp nền trang điểm dễ bị mốc hoặc đọng phấn.
            </p>
          </div>
        </div>

        <div class="concern-solution-panel">
          <div class="panel-label panel-label-solution">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <span>Giải pháp từ Fractional CC</span>
          </div>
          <p class="solution-summary">
            Quy trình làm sạch sâu cổ nang lông với acid phân tử lớn dịu nhẹ (Mandelic Acid) giải phóng bã nhờn bít tắc, phối hợp cùng tinh chất PDRN phục hồi giúp lấp đầy độ ẩm, thu nhỏ vẻ ngoài của lỗ chân lông.
          </p>
          <ul class="solution-points">
            <li><strong>Mandelic Shot Peel Essence:</strong> Tẩy da chết hóa học với kích thước phân tử lớn thẩm thấu từ từ, làm sạch dầu thừa sâu trong lỗ chân lông mà không gây khô rát.</li>
            <li><strong>PDRN Shot 1000+ Toning Essence:</strong> Cung cấp dưỡng chất sinh học PDRN giúp tăng cường độ ẩm, làm dịu và nuôi dưỡng làn da căng mướt.</li>
          </ul>
        </div>
      </div>

      <!-- Suggested Products Row -->
      <div class="concern-products-section">
        <h3 class="concern-products-heading">Sản phẩm chủ lực gợi ý:</h3>
        <div class="concern-products-grid">
          <?php
          if ( ! empty( $product_mandelic ) ) {
            get_template_part( 'template-parts/fractional/components/product-card', null, array( 'product' => $product_mandelic ) );
          }
          if ( ! empty( $product_pdrn ) ) {
            get_template_part( 'template-parts/fractional/components/product-card', null, array( 'product' => $product_pdrn ) );
          }
          ?>
        </div>
      </div>
    </section>

    <!-- 03. DA LÃO HÓA, NẾP NHĂN, CHẢY XỆ -->
    <section class="concern-card-block" id="lao-hoa">
      <div class="concern-header-row">
        <div class="concern-badge-col">
          <span class="concern-index">03</span>
          <span class="concern-tag">ĐỘ ĐÀN HỒI &amp; SĂN CHẮC</span>
        </div>
        <h2 class="heading-serif concern-block-title">DA LÃO HÓA, NẾP NHĂN, CHẢY XỆ</h2>
      </div>

      <div class="concern-analysis-grid">
        <div class="concern-pain-panel">
          <div class="panel-label panel-label-pain">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
            <span>Nỗi lòng thường gặp</span>
          </div>
          <blockquote class="concern-quote">
            “Các dấu hiệu lão hóa dần xuất hiện, làn da không còn giữ được vẻ căng mịn, đàn hồi như trước.”
          </blockquote>
          <div class="concern-insight">
            <h4 class="insight-title">Nguyên nhân từ góc nhìn khoa học:</h4>
            <p>
              Từ sau tuổi 25, mạng lưới collagen và elastin tự nhiên suy giảm dần đều. Chu kỳ thay mới tế bào da kéo dài hơn khiến các nếp nhăn biểu cảm ở khóe mắt, khóe miệng dần định hình rõ rệt, cấu trúc nâng đỡ dưới da chùng nhão.
            </p>
          </div>
        </div>

        <div class="concern-solution-panel">
          <div class="panel-label panel-label-solution">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <span>Giải pháp từ Fractional CC</span>
          </div>
          <p class="solution-summary">
            Sức mạnh từ công nghệ vi kim sinh học bọc hoạt chất vàng Retinol: Dòng Needle Serum AX4 sở hữu khoảng 600.000 vi kim (gấp 4 lần dòng A) kích hoạt phản xạ phục hồi nội sinh của làn da, hỗ trợ cải thiện độ săn chắc và làm mờ vẻ ngoài của nếp nhăn.
          </p>
          <ul class="solution-points">
            <li><strong>Needle Serum AX4 (Chuyên sâu X4):</strong> Tác động vi kim mật độ cao cùng Retinol hỗ trợ chăm sóc các nếp nhăn sâu và độ đàn hồi sụt giảm.</li>
            <li><strong>Needle Serum A (Chống lão hóa):</strong> Lựa chọn lý tưởng cho làn da bắt đầu làm quen với chu trình chống lão hóa vi kim.</li>
          </ul>
        </div>
      </div>

      <!-- Suggested Products Row -->
      <div class="concern-products-section">
        <h3 class="concern-products-heading">Sản phẩm chủ lực gợi ý:</h3>
        <div class="concern-products-grid">
          <?php
          if ( ! empty( $product_needle_ax4 ) ) {
            get_template_part( 'template-parts/fractional/components/product-card', null, array( 'product' => $product_needle_ax4 ) );
          }
          if ( ! empty( $product_needle_a ) ) {
            get_template_part( 'template-parts/fractional/components/product-card', null, array( 'product' => $product_needle_a ) );
          }
          ?>
        </div>
      </div>
    </section>

    <!-- 04. DA THÂM MỤN -->
    <section class="concern-card-block" id="tham-mun">
      <div class="concern-header-row">
        <div class="concern-badge-col">
          <span class="concern-index">04</span>
          <span class="concern-tag">PHỤC HỒI &amp; MỜ VẾT THÂM</span>
        </div>
        <h2 class="heading-serif concern-block-title">DA THÂM MỤN, TỔN THƯƠNG SAU MỤN</h2>
      </div>

      <div class="concern-analysis-grid">
        <div class="concern-pain-panel">
          <div class="panel-label panel-label-pain">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
            <span>Nỗi lòng thường gặp</span>
          </div>
          <blockquote class="concern-quote">
            “Da thâm mụn, không đều màu khiến lớp nền khó tiệp vào da, dễ lộ khuyết điểm và kém tự nhiên, khiến bạn mất thêm thời gian che phủ mỗi khi trang điểm.”
          </blockquote>
          <div class="concern-insight">
            <h4 class="insight-title">Nguyên nhân từ góc nhìn khoa học:</h4>
            <p>
              Tổn thương sau phản ứng viêm mụn kích thích tích tụ sắc tố melanin và giãn mao mạch cục bộ. Nền da sau mụn rất mỏng yếu; nếu nôn nóng dùng sản phẩm lột tẩy nồng độ cao có thể gây kích ứng ngược, làm vết thâm sậm màu hơn và kéo dài dai dẳng.
            </p>
          </div>
        </div>

        <div class="concern-solution-panel">
          <div class="panel-label panel-label-solution">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <span>Giải pháp từ Fractional CC</span>
          </div>
          <p class="solution-summary">
            Phác đồ hiệp đồng bước đệm và bước tăng cường: Bắt đầu làm quen dịu nhẹ với Serum C để củng cố nền da, sau đó nâng cấp lên Serum CX4 để tác động tầng sâu vào các gốc thâm mụn, giúp đẩy nhanh chu trình mờ thâm một cách an toàn và bền vững.
          </p>
          <div class="combo-highlight-inline">
            <div class="combo-highlight-tag">GỢI Ý HÀNG ĐẦU TỪ CHUYÊN GIA:</div>
            <p style="margin: 0; font-size: 14px; color: #3A352F;">
              <strong>Combo Siêu tinh chất vi kim giảm thâm C – CX4:</strong> Sự kết hợp được thiết kế chuyên biệt để giải quyết trọn vẹn vấn đề thâm mụn và da xỉn màu.
            </p>
          </div>
        </div>
      </div>

      <!-- Flagship Combo Card -->
      <?php if ( ! empty( $combo_c_cx4 ) ) : ?>
      <div class="concern-combo-spotlight">
        <div class="combo-spotlight-inner">
          <div class="combo-spotlight-visual">
            <img src="<?php echo esc_url( $combo_c_cx4['image'] ); ?>" alt="<?php echo esc_attr( $combo_c_cx4['name'] ); ?>" loading="lazy">
            <span class="combo-spotlight-badge"><?php echo esc_html( ! empty( $combo_c_cx4['badge'] ) ? $combo_c_cx4['badge'] : 'COMBO CHỦ LỰC' ); ?></span>
          </div>
          <div class="combo-spotlight-content">
            <div class="combo-spotlight-tag">BỘ ĐÔI ĐƯỢC KHUYÊN DÙNG NHIỀU NHẤT</div>
            <h3 class="heading-serif combo-spotlight-name"><?php echo esc_html( $combo_c_cx4['name'] ); ?></h3>
            <p class="combo-spotlight-desc">
              Liệu trình chuẩn kép: <strong>Needle Serum C</strong> (bước làm quen, nuôi dưỡng nền da sáng khỏe) kết hợp <strong>Needle Serum CX4</strong> (bước tăng cường X4 vi kim, xóa mờ thâm mụn tầng sâu). Tiết kiệm chi phí và đạt hiệu quả tối ưu cho làn da sau mụn.
            </p>
            <div class="combo-spotlight-price-row">
              <span class="combo-price-now"><?php echo esc_html( project_child_fcc_price( $combo_c_cx4['salePrice'] ) ); ?></span>
              <?php if ( ! empty( $combo_c_cx4['originalPrice'] ) ) : ?>
                <span class="combo-price-was"><?php echo esc_html( project_child_fcc_price( $combo_c_cx4['originalPrice'] ) ); ?></span>
                <span class="combo-price-save">Tiết kiệm <?php echo esc_html( project_child_fcc_price( $combo_c_cx4['saveAmount'] ) ); ?></span>
              <?php endif; ?>
            </div>
            <div class="combo-spotlight-actions">
              <button class="btn btn-primary" data-open-order data-product-select="<?php echo esc_attr( project_child_fcc_order_code( 'combo_C-CX4' ) ); ?>">
                <span>ĐẶT MUA COMBO NGAY</span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
              </button>
              <a href="<?php echo esc_url( project_child_fcc_link( 'san-pham.html#danh-sach-combo' ) ); ?>" class="btn btn-outline">
                Xem chi tiết combo
              </a>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
    </section>

    <!-- 05. NGUYÊN TẮC CHĂM SÓC DA ĐÚNG CÁCH (KHÔNG NÓI QUÁ) -->
    <section class="concerns-principles-card">
      <div class="principles-header">
        <span class="section-tag">TRIẾT LÝ DƯỠNG DA TOKYO</span>
        <h2 class="heading-serif principles-title">3 NGUYÊN TẮC VÀNG ĐỂ CHĂM SÓC DA HIỆU QUẢ</h2>
        <p class="principles-sub">
          Làn da không thể thay đổi sau một đêm. Hiểu đúng và kiên nhẫn đồng hành cùng chu trình sinh học là chìa khóa để đạt kết quả bền lâu.
        </p>
      </div>

      <div class="principles-grid">
        <div class="principle-item">
          <div class="principle-num">01</div>
          <h4 class="principle-item-title">Làm quen từ tốn &amp; Lắng nghe phản hồi</h4>
          <p class="principle-item-desc">
            Với serum vi kim, cảm giác châm chích nhẹ là phản ứng tự nhiên khi vi kim sinh học tiếp xúc biểu bì. Hãy bắt đầu với tần suất 2–3 lần/tuần trước khi dùng hàng ngày.
          </p>
        </div>

        <div class="principle-item">
          <div class="principle-num">02</div>
          <h4 class="principle-item-title">Cấp ẩm &amp; Phục hồi đầy đủ</h4>
          <p class="principle-item-desc">
            Khi vi kim kích thích quá trình thay mới tế bào, da rất cần độ ẩm để tăng sinh. Hãy kết hợp kem dưỡng ẩm hoặc serum phục hồi (như PDRN) để duy trì màng ẩm mượt mà.
          </p>
        </div>

        <div class="principle-item">
          <div class="principle-num">03</div>
          <h4 class="principle-item-title">Bảo vệ quang phổ rộng ban ngày</h4>
          <p class="principle-item-desc">
            Bảo vệ thành quả dưỡng da bằng kem chống nắng SPF50+ PA++++ mỗi sáng để ngăn chặn tia UV kích hoạt lại hắc tố melanin trên nền da đang tái tạo.
          </p>
        </div>
      </div>
    </section>

    <!-- 06. KHỐI TƯ VẤN & HỖ TRỢ TRỰC TIẾP -->
    <section class="concerns-consultation-banner">
      <div class="consultation-banner-inner">
        <div class="consultation-banner-badge">TƯ VẤN 1:1 MIỄN PHÍ TỪ BUI DANG-JP</div>
        <h2 class="heading-serif consultation-banner-title">
          BẠN CHƯA BIẾT LÀN DA MÌNH CẦN SẢN PHẨM NÀO?
        </h2>
        <p class="consultation-banner-desc">
          Mỗi làn da có cấu trúc và lịch sử chăm sóc riêng biệt. Hãy liên hệ với chuyên viên BUI DANG-JP để được soi xét tình trạng da và tư vấn phác đồ Fractional CC phù hợp nhất với bạn.
        </p>

        <div class="consultation-banner-actions">
          <button class="btn btn-primary" data-open-order>
            <span>ĐĂNG KÝ NHẬN TƯ VẤN DA</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
          </button>
          <a href="<?php echo esc_url( project_child_fcc_link( 'https://zalo.me/' . $hotline ) ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-consult-zalo">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.477 2 2 6.03 2 11C2 13.565 3.195 15.864 5.12 17.472L4.2 21.2C4.085 21.664 4.545 22.052 4.965 21.848L9.29 19.742C10.158 19.911 11.063 20 12 20C17.523 20 22 15.97 22 11C22 6.03 17.523 2 12 2Z"></path></svg>
            <span>Nhắn Zalo chuyên viên</span>
          </a>
          <a href="<?php echo esc_url( project_child_fcc_link( 'tel:' . $hotline ) ); ?>" class="btn btn-consult-phone">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
            <span>Hotline: <?php echo esc_html( $hotline_display ); ?></span>
          </a>
        </div>

        <div class="consultation-trust-pills">
          <span class="trust-pill-item">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DFBA73" stroke-width="2.2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><path d="m9 12 2 2 4-4"></path></svg>
            100% Chính Hãng BUI DANG-JP
          </span>
          <span class="trust-pill-sep">•</span>
          <span class="trust-pill-item">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DFBA73" stroke-width="2.2"><path d="M20 6L9 17l-5-5"></path></svg>
            Giao Hàng &amp; Đồng Kiểm Toàn Quốc
          </span>
          <span class="trust-pill-sep">•</span>
          <span class="trust-pill-item">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#DFBA73" stroke-width="2.2"><rect width="20" height="14" x="2" y="5" rx="2"></rect><line x1="2" x2="22" y1="10" y2="10"></line></svg>
            Đổi Trả Trong 7 Ngày
          </span>
        </div>
      </div>
    </section>

  </div>
</div>
