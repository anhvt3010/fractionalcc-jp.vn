<?php
/**
 * Skin Concerns & Solutions page template parts assembler.
 *
 * @package Project_Child
 */
defined( 'ABSPATH' ) || exit;
?>
<?php get_template_part( 'template-parts/fractional/shared/part-3f6d3a685ae7' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-d5d7fa3d16ec' ); ?>
<main class="concerns-page-wrap">
<?php get_template_part( 'template-parts/fractional/concerns/section-01' ); ?>
</main>
<?php get_template_part( 'template-parts/fractional/shared/part-09e851b50cc0' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-ce4f8f0f73e0' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-06227b06833a' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-8e6ab1da227f' ); ?>
