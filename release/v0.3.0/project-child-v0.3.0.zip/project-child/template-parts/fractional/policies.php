<?php
defined( 'ABSPATH' ) || exit;
?>
<?php get_template_part( 'template-parts/fractional/shared/part-3f6d3a685ae7' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-63d9a46f49eb' ); ?>
<main class="policy-page-wrap">
<?php get_template_part( 'template-parts/fractional/policies/section-01' ); ?>
</main>
<?php get_template_part( 'template-parts/fractional/shared/part-7fd0d87e8990' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-53850285c59e' ); ?>
