<?php
defined( 'ABSPATH' ) || exit;
?>
<?php get_template_part( 'template-parts/fractional/shared/part-06cfc0b96783' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-72a33a60efc7' ); ?>
<main>
<?php get_template_part( 'template-parts/fractional/catalog/section-01' ); ?>
<?php get_template_part( 'template-parts/fractional/catalog/section-02' ); ?>
<?php get_template_part( 'template-parts/fractional/catalog/section-03' ); ?>
<?php get_template_part( 'template-parts/fractional/catalog/section-04' ); ?>
</main>
<?php get_template_part( 'template-parts/fractional/shared/part-4598da797fab' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-6cdb3dc2515b' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-0bd7e57cd914' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-6381ad0fd07c' ); ?>
