<?php
defined( 'ABSPATH' ) || exit;
?>
<?php get_template_part( 'template-parts/fractional/shared/part-8fe73eaef545' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-57e984670dbc' ); ?>
<main>
<?php get_template_part( 'template-parts/fractional/home/section-01' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-02' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-03' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-04' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-05' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-06' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-07' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-08' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-09' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-10' ); ?>
<?php get_template_part( 'template-parts/fractional/home/section-11' ); ?>
</main>
<?php get_template_part( 'template-parts/fractional/shared/part-2b1568851566' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-853868856d1b' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-b8357a936a38' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-618d57e06a6b' ); ?>
