<?php
defined( 'ABSPATH' ) || exit;
?>
<?php get_template_part( 'template-parts/fractional/shared/part-f91ad1592181' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-5162efc0f698' ); ?>
<main class="thankyou-page">
<?php get_template_part( 'template-parts/fractional/thankyou/section-01' ); ?>
</main>
<?php get_template_part( 'template-parts/fractional/shared/part-7fd0d87e8990' ); ?>
