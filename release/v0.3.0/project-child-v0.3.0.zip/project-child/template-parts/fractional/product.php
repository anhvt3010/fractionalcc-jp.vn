<?php
defined( 'ABSPATH' ) || exit;
?>
<?php get_template_part( 'template-parts/fractional/shared/part-8fe73eaef545' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-17d24d7a61fe' ); ?>
<main class="pd-page-container" id="product-detail-view">
<?php get_template_part( 'template-parts/fractional/product/section-01' ); ?>
<?php get_template_part( 'template-parts/fractional/product/section-02' ); ?>
</main>
<?php get_template_part( 'template-parts/fractional/shared/part-c62fe9c42f7c' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-f404a8150472' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-6a55c7b782d1' ); ?>
<?php get_template_part( 'template-parts/fractional/shared/part-9b3d18482d56' ); ?>
